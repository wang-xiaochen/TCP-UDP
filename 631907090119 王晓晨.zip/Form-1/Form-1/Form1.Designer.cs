﻿
namespace Form_1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSend = new System.Windows.Forms.Button();
            this.textInput = new System.Windows.Forms.TextBox();
            this.textShowMsg = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(648, 355);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(95, 25);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.button1_Click);
            // 
            // textInput
            // 
            this.textInput.Location = new System.Drawing.Point(12, 355);
            this.textInput.Name = "textInput";
            this.textInput.Size = new System.Drawing.Size(630, 25);
            this.textInput.TabIndex = 1;
            // 
            // textShowMsg
            // 
            this.textShowMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textShowMsg.Location = new System.Drawing.Point(12, 12);
            this.textShowMsg.Multiline = true;
            this.textShowMsg.Name = "textShowMsg";
            this.textShowMsg.ReadOnly = true;
            this.textShowMsg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textShowMsg.Size = new System.Drawing.Size(731, 335);
            this.textShowMsg.TabIndex = 2;
            this.textShowMsg.WordWrap = false;
            this.textShowMsg.TextChanged += new System.EventHandler(this.tbShowMsg_TextChanged);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnSend;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(747, 389);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.textShowMsg);
            this.Controls.Add(this.textInput);
            this.MaximumSize = new System.Drawing.Size(765, 436);
            this.Name = "Form1";
            this.Text = "客户端";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox textInput;
        private System.Windows.Forms.TextBox textShowMsg;
    }
}

