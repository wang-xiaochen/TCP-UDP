﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textShowMsg = new System.Windows.Forms.TextBox();
            this.textInput = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textShowMsg
            // 
            this.textShowMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textShowMsg.Enabled = false;
            this.textShowMsg.Location = new System.Drawing.Point(81, 50);
            this.textShowMsg.Multiline = true;
            this.textShowMsg.Name = "textShowMsg";
            this.textShowMsg.ReadOnly = true;
            this.textShowMsg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textShowMsg.Size = new System.Drawing.Size(646, 295);
            this.textShowMsg.TabIndex = 0;
            this.textShowMsg.TextChanged += new System.EventHandler(this.tbShowMsg_TextChanged);
            // 
            // textInput
            // 
            this.textInput.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textInput.Location = new System.Drawing.Point(81, 351);
            this.textInput.Name = "textInput";
            this.textInput.Size = new System.Drawing.Size(546, 25);
            this.textInput.TabIndex = 1;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(633, 351);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(94, 29);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnSend;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.textInput);
            this.Controls.Add(this.textShowMsg);
            this.Name = "Form1";
            this.Text = "客户端";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textShowMsg;
        private System.Windows.Forms.TextBox textInput;
        private System.Windows.Forms.Button btnSend;
    }
}

