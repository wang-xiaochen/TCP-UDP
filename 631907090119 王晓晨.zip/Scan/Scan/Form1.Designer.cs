﻿
using System;

namespace Scan
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbHost = new System.Windows.Forms.TextBox();
            this.tbSPort = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbEPort = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pb = new System.Windows.Forms.ProgressBar();
            this.lb = new System.Windows.Forms.Label();
            this.tbShow = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "主机地址";
            // 
            // tbHost
            // 
            this.tbHost.Location = new System.Drawing.Point(133, 40);
            this.tbHost.Name = "tbHost";
            this.tbHost.Size = new System.Drawing.Size(100, 25);
            this.tbHost.TabIndex = 3;
            // 
            // tbSPort
            // 
            this.tbSPort.Location = new System.Drawing.Point(133, 95);
            this.tbSPort.Name = "tbSPort";
            this.tbSPort.Size = new System.Drawing.Size(100, 25);
            this.tbSPort.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "起始端口";
            // 
            // tbEPort
            // 
            this.tbEPort.Location = new System.Drawing.Point(133, 149);
            this.tbEPort.Name = "tbEPort";
            this.tbEPort.Size = new System.Drawing.Size(100, 25);
            this.tbEPort.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "终止端口";
            // 
            // pb
            // 
            this.pb.Location = new System.Drawing.Point(55, 208);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(100, 23);
            this.pb.TabIndex = 8;
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Location = new System.Drawing.Point(161, 212);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(23, 15);
            this.lb.TabIndex = 9;
            this.lb.Text = "0%";
            // 
            // tbShow
            // 
            this.tbShow.Location = new System.Drawing.Point(284, 12);
            this.tbShow.Multiline = true;
            this.tbShow.Name = "tbShow";
            this.tbShow.ReadOnly = true;
            this.tbShow.Size = new System.Drawing.Size(374, 376);
            this.tbShow.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(72, 310);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 31);
            this.button1.TabIndex = 12;
            this.button1.Text = "开始扫描";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 397);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbShow);
            this.Controls.Add(this.lb);
            this.Controls.Add(this.pb);
            this.Controls.Add(this.tbEPort);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbSPort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbHost);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbHost;
        private System.Windows.Forms.TextBox tbSPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbEPort;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar pb;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.TextBox tbShow;
        private System.Windows.Forms.Button button1;
    }
}

